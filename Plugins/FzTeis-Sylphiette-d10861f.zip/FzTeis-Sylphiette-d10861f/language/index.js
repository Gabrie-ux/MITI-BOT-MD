
import en from './en.js' 
import es from './es.js' 

export {en, es}
