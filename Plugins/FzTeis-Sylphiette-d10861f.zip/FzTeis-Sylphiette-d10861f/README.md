<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&height=150&section=header&text=Sylphiette%20-%20The%20Best%20🧝‍♂️&fontSize=30&fontColor=FFFFFF&animation=fadeIn" width="100%"/> 
<p align="center"> 
<img src="https://telegra.ph/file/984d8ca31c6552a19f378.jpg" />
<p/>
<p align="center">
<a href="https://github.com/FzTeis"><img title="Author" src="https://img.shields.io/badge/Sylphiette-black?style=for-the-badge&logo=whatsApp"></a>
<p/>

<div align="center">

[![WhatsApp](https://img.shields.io/badge/CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://whatsapp.com/channel/0029Va6InNBFCCoM9xzKFG3G)
[![WhatsApp](https://img.shields.io/badge/Support-2CA5E0?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5212431268546)
[![WhatsApp](https://img.shields.io/badge/GROUP-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/IZnTbIcSVI6EXYHII2hlrK)
[![WhatsApp](https://img.shields.io/badge/Sylph-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/17146121800?text=/menu) 

</div>

<h3 align="center">WHATSAPP BOT</h3>

***
<p align="center">
<a href="#"><img title="SylphBot" src="https://img.shields.io/badge/¡¡Gracias por usar a Sylphiette!!-red?colorA=%255ff0000&colorB=%23017e40&style=for-the-badge"></a> 
</p>  

[ 🌱 ] Multi-idioma para cada usuario, lo que significa que el usuario puede elegir el idioma que quiere usar

- [x] Español
- [x] Inglés

***
### **`☄️ Sky Ultra Plus:`**
<a href="https://dash.skyultraplus.com/"><img src="https://i.ibb.co/X8knsB6/Sylph.jpg" height="130px"></a>

<details>
 <summary><b>Click para mostrar los links</b></summary>

- **Panel:** [`Aquí`](https://panel.skyultraplus.com)
- **Registrarse:** [`Aquí`](https://dash.skyultraplus.com/register?ref=8N9gN0fj)
</details>

### **`🚀 TK HOST:`**
<a href="https://dash.tk-joanhost.com"><img src="https://i.ibb.co/pr8TnWJ/SAVE-20240915-183758.jpg" height="130px"></a>

<details>
 <summary><b>:paperclip: Enlaces Importantes</b></summary>

- **Dashboard:** [`Aquí`](https://dash.tk-joanhost.com)
- **Panel:** [`Aquí`](https://panel.tk-joanhost.com)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VaoZXbk6RGJNYQVP8r27)
- **Registrarse:** [`Aquí`](https://dash.tk-joanhost.com/register?ref=8DSQVA9e)
</details>

### **`⛲ Hosting Py:`**
<a href="https://dahs.hostingpy.shop/"><img src="https://files.catbox.moe/lr92z2.jpg" height="130px"></a>

<details>
 <summary><b>Click para mostrar los links</b></summary>

- **Dashboard:** [`Aquí`](https://dahs.hostingpy.shop/)
- **Registrarse:** [`Aquí`](https://dahs.hostingpy.shop/register?ref=qynHnQnY)
</details>

***

### TERMUX
Comandos:
```sh
$ No hay pijes, de momento solo funciona en servicios Hosting que ofrezcan nodejs como los de arriba 🕊️
```
1. Esperar a que se inicie el bot...
2. Elige una de las opciones para establecer la conexión.
3. Escanea el código QR u introduce el codigo de 8 digitos desde el segundo dispositivo. (ir a whatsapp > Dispositivos Vinculados > Vincular un dispositivo)

---------
### 🌟 AGRADECIMIENTOS
[![TheShadowBrokers1](https://github.com/BrunoSobrino.png?size=60)](https://github.com/BrunoSobrino)
[![FG98F](https://github.com/FG98F.png?size=60)](https://github.com/FG98F) 
<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&height=150&section=footer" width="100%"/>